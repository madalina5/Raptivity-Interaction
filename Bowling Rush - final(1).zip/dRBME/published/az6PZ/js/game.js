$('.bowling-pinsdown').click(function () {
	$('.bowling-pinsdown').each(function () {
		this.play();
	});
});

$('.bowling-pin-fall').click(function () {
	$('.bowling-pin-fall').each(function () {
		this.play();
	})
});

$('.bowling-not-pin-boll').click(function () {
	$('.bowling-not-pin-boll').each(function () {
		this.play();
	})
});

$('.bowling-audio').click(function () {
	$('.bowling-audio').each(function () {
		this.play();
	})
})

function gameHitAudio() {
	$('.bowling-audio').click()
	setTimeout(function () {
		$('.bowling-pinsdown').click()
		setTimeout(function () {
			$('.bowling-audio').each(function () {
				this.pause();
				this.currentTime = 0;
			})
			if (userAnswer == true) {
				$('.bowling-pin-fall').click()
			} else {
				$('.bowling-not-pin-boll').click()
			}
			setTimeout(function () {
				setTimeout(function () {
					$('.bowling-not-pin-boll,.bowling-pin-fall').each(function () {
						this.pause();
						this.currentTime = 0;
					})
				}, 2000)
			}, 2000)
		}, 500)
	}, 2000)
}

function gameStart() {
	$('.disabledpointer').css('pointer-events', 'none')
	gameHitAudio()
	$('.information-panel .img-sec').css('transform', 'scale(1.8)')
	$('.bowling-ball').attr('src', './images/bowling_ball.gif')
	if (userAnswer == true) {
		$('.bowling-ball').css({
			'transition': 'all 3s',
			'visibility': 'visible',
			'top': '45%',
			'transform': 'translateY(-45%) scale(0.7)'
		})
		// $('.bowling-pins,.bowling-ball-true-gif').show().css({
		// 	'top': '43%',
		// 	'transform': 'translateY(-43%) scale(1.8)'
		// })
	} else {
		if ($(window).width() < 900 && window.innerHeight < window.innerWidth) {
			$('.bowling-ball').css({
				'transition': 'all 3s',
				'visibility': 'visible',
				'top': '45%',
				'left': '-56px',
				'transform': 'translateY(-45%) scale(0.7)'
			})
		} else {
			$('.bowling-ball').css({
				'transition': 'all 3s',
				'visibility': 'visible',
				'top': '45%',
				'left': '-100px',
				'transform': 'translateY(-45%) scale(0.7)'
			})
		}
		// $('.bowling-pins,.bowling-ball-false-gif').show().css({
		// 	'top': '43%',
		// 	'transform': 'translateY(-43%) scale(1.8)'
		// })
	}
	setTimeout(function () {
		if (userAnswer == true) {
			// $('.bowling-ball-true-gif').css({
			// 	'transition': 'all 0s',
			// 	'visibility': 'visible'
			// })
			// $('.bowling-ball-true-gif').attr('src', '')
			$('.bowling-pins').attr('src', './images/pins-non-loop.gif')
		} else {
			// $('.bowling-ball-false-gif').css({
			// 	'transition': 'all 0s',
			// 	'visibility': 'visible'
			// })
			// $('.bowling-ball-false-gif').attr('src', '')
			$('.bowling-pins').attr('src', './images/2BattleFallen3.gif')
		}
		setTimeout(function () {
			$('.bowling-ball').css({
				'transition': 'all 0s',
				'visibility': 'hidden',
			})
			if (userAnswer == true) {
				setTimeout(function () {
					$('.bowling-ball-true-gif').css({
						'visibility': 'hidden',
					})
				}, 1000)
				$('.game_bonus_Image').attr('src', '')
				$('.game_bonus_Image').attr('src', './images/transition.gif')
				$('.game_bonus_first_text').text(interactionJSON.textConstant.Slides.STRIKE)
				$('.game_bonus').fadeIn()
			} else {
				$('.game_bonus_Image').attr('src', '')
				$('.game_bonus_Image').attr('src', './images/transition-fail.gif')
				$('.game_bonus_first_text').text(interactionJSON.textConstant.Slides.MISSED_STRIKE)
				$('.game_bonus').fadeIn()
			}
			// $('.bowling-ball1').hide()
			setTimeout(function () {
				$('.bowling-pins,.bowling-ball-false-gif,.bowling-ball-true-gif').css({
					'transition': 'all 3s',
				})
				restartGame()
				setTimeout(function () {
					nextAnswer()
					$(".game_bonus").fadeOut();
					if ($(window).width() < 900) {
						$('.game-based-temp').css('right', '0')
						$('.gamezone').css('left', '100%')
					}
				}, 2000)
			}, 2000)
		}, 500)
	}, 2000)
}

function restartGame() {
	$('.bowling-pins').hide()
	$('.information-panel .img-sec').css({
		'transform': 'scale(1)'
	})
	$('.bowling-pins').show().css({
		'top': '17.5%',
	})
	// $('.bowling-ball-true-gif').show()
	// $('.bowling-ball-true-gif').attr('src', '')
	// $('.bowling-ball-true-gif').attr('src', './images/pins-non-loop.gif')
	// $('.bowling-ball-false-gif').attr('src', '')
	// $('.bowling-ball-false-gif').attr('src', './images/2BattleFallen3.gif')
	$('.bowling-pins,.bowling-ball-false-gif,.bowling-ball-true-gif').css({
		'top': '17.5%',
	})
	setTimeout(function () {
		$('.bowling-ball-false-gif').css({
			'visibility': 'hidden',
		})
		$('.bowling-pins').attr({ 'src': './images/pins-single.png' })
		// $('.bowling-pins').css({ 'visibility': 'visible' })
		$('.bowling-ball').attr({ 'src': './images/bowling_ball.png' })
		$('.bowling-ball').css({
			'visibility': 'visible',
			'top': '100%',
			'left': '0',
			'transform': 'translateY(-100%) scale(1)'
		})
	}, 2000);

}
