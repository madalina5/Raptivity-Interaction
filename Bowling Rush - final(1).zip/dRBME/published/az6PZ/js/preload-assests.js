$(document).ready(function() {
  var totalImages = [
    './images/speaker_off.svg',
    './images/speaker_on.svg',
    './images/question.svg',
    './images/clock.svg',
    './images/Watermark%20Logo.png',
    './images/Bowling_bg-image.svg',
    './images/pins-single.png',
    './images/bowling_ball.png',
    './images/bowling_ball.gif',
    './images/transition.gif',
    './images/transition-fail.gif',
    './images/score.svg',
    './images/correct.png',
    './images/wrong.png'
  ];

  for (let index = 0; index < totalImages.length; index++) {
    const element = totalImages[index];
    const img = new Image();

    img.src = element;
  }
});
